import java.util.*;
public class Jugadores {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        boolean menu = true;
        List nombres = new ArrayList<>();
        System.out.println("Ingrese el numero de jugadores:\nPresione 0 para salir ");
        int integrantes = scanner.nextInt();
        
        if(integrantes == 2) {
            for(int i = 0; i < integrantes; i++){
                nombres.add(scanner.nextLine());
                System.out.println("Ingrese los nombres del jugador "+ (i+1));
                
            }
            System.out.println(".....................Juego Iniciado....................\n");

        } else if(integrantes == 3){
            for(int i = 0; i < integrantes; i++){
                System.out.println("Ingrese los nombres del jugador"+ i);
                nombres.add(scanner.nextLine());
            }
            
        } else if(integrantes ==4 ){
            for(int i = 0; i < integrantes; i++){
                System.out.println("Ingrese los nombres del jugador"+ i);
                nombres.add(scanner.nextLine());
            }
            
        } else if(integrantes <2 && integrantes != 0){
            System.out.println("Se nesesita un minimo de 2 integrantes");
        } else if(integrantes > 4){
            System.out.println("maximo de 4 jugadores");
        } else if(integrantes == 0){
            menu = false;
        }
    
    }
}