import java.util.*;

public class Main{
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        // Contiene todas todas las cartas
        int cartas[] = new int[13];
        Random random = new Random();
        ArrayList lista = new ArrayList<>();
        //tipos de cartas
        lista.add("Corazones"); 
        lista.add("Diamantes");
        lista.add("Trevoles");
        lista.add("Picas");
        // corregir que se repitan numeros mas de 4 veces
        for (int i = 0; i < cartas.length; i++){
            cartas[i] = random.nextInt(12) +1;
        }
        // escoje un valor aleatorio de los tipas de cartas
        int aleatorio_1 = random.nextInt(4);
        int aleatorio_2 = random.nextInt(4);
        int aleatorio_3 = random.nextInt(4);
        int aleatorio_4 = random.nextInt(4);
        int aleatorio_5 = random.nextInt(4);
        // Estas variables representas las 5 cartas iniciales de cada jugador,
        // estas escojen una carta dentro del arreglo de cartas.
        int primera = cartas[0];
        int segunda = cartas[1];
        int tercera = cartas[2];
        int cuarta = cartas[3];
        int quinta = cartas[4];
        // Estas variables guaradan los tipos de cartas "Especiales"
        String As = "As";
        String Jack = "Jack";
        String Reina = "Reina";
        String Rey = "Rey";
        
        ArrayList fichas = new ArrayList<>();
        for(int i = 1; i <= 100; i++){
            fichas.add(i);
        }
        int fichasRestantes = 100;
        // Guarda las fichas que se han apostado
        ArrayList fichasApostadas = new ArrayList<>();
        // primer bucle del juego
        boolean menu = true;
        System.out.println(" escoja las cartas que desea observar\n.....................Nota......................");
        System.out.println(".Para ver todas las cartas ingrese el numero 6.\n.Para apostar ingrese el numero 0..............");
        // Este while nos da la opcion de ver las cartas y apostar fichas.
        while(menu){
            System.out.println("\n\ncarta 1\ncarta 2\ncarta 3\ncarta 4\ncarta 5");
            System.out.println("\n                                                fichas " + fichasRestantes+"\napostar" + fichasApostadas);
            int ingresar = scanner.nextInt();
        
            if(ingresar == 1){ // Permite ver y en un futuro intercambiar la carta 1 con alguna de la baraja.
               if(primera == 1){// muestra un As si la primera carta es un 1.
                   System.out.println(As +" de "+lista.get(aleatorio_1));
                } else if( primera == 11){ // muestra un Jack si la primera carta es un 11.
                   System.out.println(Jack +" de "+lista.get(aleatorio_1));
               } else if(primera == 12){ // muestra una Reina si la primera carta es un 12.
                   System.out.println(Reina +" de "+lista.get(aleatorio_1));
               } else if(primera == 13){ // muestra un Rey si la primera carta es un 13.
                   System.out.println(Rey +" "+lista.get(aleatorio_1));
               } else { // muestra sin mas el numero de la primera carta si no cumple con las condiciones anteriores.
                   System.out.println(primera +" "+lista.get(aleatorio_1));
                }
            } else if ( ingresar == 2){ // Permite ver y en un futuro intercambiar la carta 2 con alguna de la baraja.
               if(segunda == 1){ // muestra un As si la segunda carta es un 1.
                    System.out.println(As +" de "+lista.get(aleatorio_2));
               } else if( segunda == 11){ // muestra un Jack si la segunda carta es un 11.
                   System.out.println(Jack +" de "+lista.get(aleatorio_2));
               } else if(segunda == 12){ // muestra una Reina si la segunda carta es un 12.
                   System.out.println(Reina +" de "+lista.get(aleatorio_2));
               } else if(segunda == 13){ // muestra un Rey si la segunda carta es un 13.
                   System.out.println(Rey +" de "+lista.get(aleatorio_2));
               } else{ // muestra sin mas el numero de la segunda carta si no cumple con las condiciones anteriores.
                   System.out.println(segunda +" "+lista.get(aleatorio_2));
               }
            } else if( ingresar == 3){ // Permite ver y en un futuro intercambiar la carta 3 con alguna de la baraja.
               if( tercera == 1){ // muestra un As si la tercera carta es un 1.
                   System.out.println(As +" de "+lista.get(aleatorio_3));
                } else if( tercera == 11){ // muestra un Jack si la tercera carta es un 11.
                   System.out.println(Jack +" de "+lista.get(aleatorio_3));
               } else if(tercera == 12){ // muestra una Reina si la tercera carta es un 12.
                   System.out.println(Reina +" de "+lista.get(aleatorio_3));
               } else if(tercera == 13){ // muestra un Rey si la tercera carta es un 13.
                   System.out.println(Rey +" de "+lista.get(aleatorio_3));
               } else { // muestra sin mas el numero de la tercera carta si no cumple con las condiciones anteriores.
                   System.out.println(tercera +" "+lista.get(aleatorio_3));
               }
            } else if(ingresar == 4){ // Permite ver y en un futuro intercambiar la carta 4 con alguna de la baraja.
               if( cuarta == 1){ // muestra un As si la cuarta carta es un 1.
                   System.out.println(As +" de "+lista.get(aleatorio_4));
                }else if( cuarta == 11){ // muestra un Jack si la cuarta carta es un 11.
                   System.out.println(Jack +" de "+lista.get(aleatorio_4));
               } else if(cuarta == 12){ // muestra una Reina si la cuarta carta es un 12.
                   System.out.println(Reina +" de "+lista.get(aleatorio_4));
               } else if (cuarta == 13) { // muestra un Rey si la cuarta carta es un 13.
                   System.out.println(Rey +" de "+lista.get(aleatorio_4));
               } else{ // muestra sin mas el numero de la cuarta carta si no cumple con las condiciones anteriores.
                   System.out.println(cuarta +" "+lista.get(aleatorio_4));
               }
            } else if(ingresar == 5){ // Permite ver y en un futuro intercambiar la carta 5 con alguna de la baraja.
               if ( quinta == 1){ // muestra un As si la quinta carta es un 1.
                   System.out.println(As +" de "+lista.get(aleatorio_5));
                } else if( quinta == 11){ // muestra un Jack si la quinta carta es un 11.
                   System.out.println(Jack +" de "+lista.get(aleatorio_5));
               } else if(quinta== 12){ // muestra una Reina si la quinta carta es un 12.
                   System.out.println(Reina +" de "+lista.get(aleatorio_5));
               } else if(quinta == 13) { // muestra un Rey si la quinta carta es un 13.
                   System.out.println(Rey +" de "+lista.get(aleatorio_5));
               } else{ // muestra sin mas el numero de la quinta carta si no cumple con las condiciones anteriores.
                   System.out.println(quinta +" "+lista.get(aleatorio_5));
               }
            } else if(ingresar == 6){ // Muestra las 5 cartas al jugador.
               // Posibilidades de la primer carta. 
                if(primera == 1){
                   System.out.println(As +" de "+lista.get(aleatorio_1));
                } else if( primera == 11){
                   System.out.println(Jack +" de "+lista.get(aleatorio_1));
               } else if(primera == 12){
                   System.out.println(Reina +" de "+lista.get(aleatorio_1));
               } else if(primera == 13){
                   System.out.println(Rey +" "+lista.get(aleatorio_1));
               } else {
                   System.out.println(primera +" "+lista.get(aleatorio_1));
                }
               // Posibilidades de la segunda carta.
               if(segunda == 1){
                    System.out.println(As +" de "+lista.get(aleatorio_2));
               } else if( segunda == 11){
                   System.out.println(Jack +" de "+lista.get(aleatorio_2));
               } else if(segunda == 12){
                   System.out.println(Reina +" de "+lista.get(aleatorio_2));
               } else if(segunda == 13){
                   System.out.println(Rey +" de "+lista.get(aleatorio_2));
               } else{
                   System.out.println(segunda +" "+lista.get(aleatorio_2));
               }
               // Posibilidades de la tercera carta.   
               if( tercera == 1){
                   System.out.println(As +" de "+lista.get(aleatorio_3));
                } else if( tercera == 11){
                   System.out.println(Jack +" de "+lista.get(aleatorio_3));
               } else if(tercera == 12){
                   System.out.println(Reina +" de "+lista.get(aleatorio_3));
               } else if(tercera == 13){
                   System.out.println(Rey +" de "+lista.get(aleatorio_3));
               } else {
                   System.out.println(tercera +" "+lista.get(aleatorio_3));
               }
               // Posibilidades de la cuarta carta.  
               if( cuarta == 1){
                   System.out.println(As +" de "+lista.get(aleatorio_4));
                }else if( cuarta == 11){
                   System.out.println(Jack +" de "+lista.get(aleatorio_4));
               } else if(cuarta == 12){
                   System.out.println(Reina +" de "+lista.get(aleatorio_4));
               } else if (cuarta == 13) {
                   System.out.println(Rey +" de "+lista.get(aleatorio_4));
               } else{
                   System.out.println(cuarta +" "+lista.get(aleatorio_4));
               }
               // Posibilidades de la quinta carta.   
               if ( quinta == 1){  
                   System.out.println(As +" de "+lista.get(aleatorio_5));
                } else if( quinta == 11){
                   System.out.println(Jack +" de "+lista.get(aleatorio_5));
               } else if(quinta== 12){
                   System.out.println(Reina +" de "+lista.get(aleatorio_5));
               } else if(quinta == 13) {
                   System.out.println(Rey +" de "+lista.get(aleatorio_5));
               } else{
                   System.out.println(quinta +" "+lista.get(aleatorio_5));
               }
                
            } else if(ingresar == 0){ // Metodo para apostar/ En proceso.
                System.out.println("¿Cuanto desea apostar?");
                int apostarFichas = scanner.nextInt();
                if(apostarFichas%5 == 0){ // Permite que solo se efectuen apuestas multiplo de 5.
                    if(apostarFichas < 0){ // Si el numero ingresado por el usuario es negativo, este se pasa a un valor positiva.
                        // Como el valor es negativo en este If, se suma a fichasRestantes, para que se muestre el total de fichas que quedan.
                        fichasRestantes = fichasRestantes + apostarFichas;
                        // Como el valor es negtivo en este If, al añadirlo a la lista, este se pasa a positivo.
                        fichasApostadas.add(apostarFichas*-1);
                    } else{ // caso ideal en el que el usuario ingresa un numero positivo.
                        // Este se pasa a negativo para restarlo de las fichas Restantes.
                        apostarFichas = apostarFichas * -1;
                        // Las fichas apostadas se restan del total de fichas restantes.
                        fichasRestantes = fichasRestantes + apostarFichas;
                        // Las fichas apostadas se añade a la lista de fichasApostadas
                        fichasApostadas.add(apostarFichas*-1);
                    }
                } else { // Caso en el que el usuario no ingreso una apuesta multiplo de 5.
                    System.out.println("Solo se pueden hacer apuestas de multiplos de 5");
                }
            } else if( fichasRestantes < 0){ // Si el jugador se queda sin fichas, el juego termina. / En proceso
                System.out.println("Usted se a quedado sin fichas\n\n.......Fin del Juego......");
                menu = false;
            }
        }
    }
}